from pathlib import Path
import hashlib,json,shutil,plistlib,sys,importlib.metadata
import pyarrow as pa,pyarrow.dataset as ds,pyarrow.parquet as pq
O=Path(__file__).resolve().parent
base=Path('/Users/lexi/Library/Application Support'); S=base/'com.lexi.v35.local/state'; A=base/'com.lexi.v4.local/releases/hk-dated-name-20261011-r2/app'; R=base/'com.lexi.v4.local/releases/hk-auto-d1-20261011-r1/app'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
refs=[]
def copy(p,label):
 if not p.is_file(): return {'path':str(p),'exists':False}
 q=O/label;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q);r={'path':str(p),'copy':label,'sha256':sha(p),'size':p.stat().st_size,'is_symlink':p.is_symlink()};refs.append(r);return r
def save(n,d): (O/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
p=S/'workspace/数据/data_layer_interface_current/CURRENT_SELECTOR_READY_PANEL.txt';target=Path(p.read_text().strip())
info={'pointer':copy(p,'originals/CURRENT_SELECTOR_READY_PANEL.txt'),'process_cwd':str(R),'resolution':'Path(pointer text), relative to process cwd, NOT pointer parent','target':str(target),'target_size':target.stat().st_size,'target_is_symlink':target.is_symlink(),'target_sha256':sha(target)}
D=ds.dataset(str(target),format='parquet'); (O/'original_schema.txt').write_text(str(D.schema))
cols=['trade_date','ts_code','name','pct_chg','amount','bar_close_pos','tdx_industry_code','tdx_industry_name']
type_=D.schema.field('trade_date').type; value=20261009 if pa.types.is_integer(type_) else '20261009'
t=D.to_table(columns=cols,filter=ds.field('trade_date')==value);q=O/'originals/panel_20261009_required8.parquet';pq.write_table(t,q);df=t.to_pandas(); members=sorted(set(df.ts_code.astype(str)))
(O/'originals/membership_20261009.txt').write_text('\n'.join(members)+'\n')
info.update({'trade_date':'20261009','source_date_type':str(type_),'row_count':len(df),'unique_members':len(members),'duplicate_code_rows':int(df.ts_code.duplicated().sum()),'missing_or_nan':{c:int(df[c].isna().sum()) for c in cols},'empty_strings':{c:int(df[c].astype(str).str.strip().eq('').sum()) for c in cols},'copy_sha256':sha(q),'copy_size':q.stat().st_size,'membership_sha256':sha(O/'originals/membership_20261009.txt'),'membership_declaration':'All source rows matching T retained, original order and Arrow types; only required 8 columns selected. No filtering, deduplication, fill, synthesis. This is complete membership of source T rows, NOT proof of complete market coverage.'})
save('panel_evidence.json',info)
for label,p in [('panel_source_receipt',S/'research_panel_daily/receipts/a-20261009.json'),('a_share_existing_receipt',S/'data/a_share_reviews/receipts/20261009.json'),('a_share_existing_review',S/'data/a_share_reviews/20261009.json'),('dispatcher_pointer',S/'data/.dispatcher_tmp/selector_panel_pointer.txt'),('daily_pointer',S/'data/.daily_tmp/selector_panel_pointer.txt')]:copy(p,'originals/'+label+p.suffix)
for root,label in [(A,'active_api'),(R,'scheduler')]:
 for f in (['apps/api/v35_api/review_router.py','domains/review_evidence_layers.py','infrastructure/a_share_review_store.py','apps/web/src/views/ReviewView.vue','apps/api/v35_api/app.py'] if label=='active_api' else ['ops/build_a_share_close_review.py','infrastructure/scheduling/executor_registry_review.py','ops/run_v35_macos_scheduler.py','ops/launch_v35_macos_scheduler.sh','contracts/runtime_workloads.json','contracts/close_timeline.py','contracts/market_calendar_2026.json']):copy(root/f,'binding_source/'+label+'/'+f)
bindings={}
for n in ['com.lexi.v35.api-only','com.lexi.v35.scheduler']:
 f=Path.home()/'Library/LaunchAgents'/f'{n}.plist';d=plistlib.loads(f.read_bytes()); env=dict(d.get('EnvironmentVariables',{}));args=d.get('ProgramArguments',[])
 for arg in args:
  if '=' in arg and not arg.startswith('/'):
   k,v=arg.split('=',1);env[k]=v
 wanted={k:v for k,v in env.items() if k in ['V35_RELEASE_ID','V35_DATA_ROOT','V35_APP_ROOT','V35_RESEARCH_DATA_ROOT','V35_RESEARCH_PANEL_A_SELECTOR_POINTER','TZ'] or 'REVIEW_CORE' in k}
 bindings[n]={'plist_sha256':sha(f),'working_directory':d.get('WorkingDirectory'),'selected_nonsecret_environment':wanted,'program_executable':args[0]}
save('runtime_bindings.json',bindings)
optional=[]
for root in [S/'data',base/'com.lexi.v4.local/state/data']:
 for f in ['selector_pointer.txt','transcript_stockdict/current_asr_pointer.json','stock_mentions.json','video_ocr_alignment/alignment_pointer.json','video_gap/video_gap_audit.json','video_session.json']:
  p=root/'close_review_sources/20261009/bilibili'/f;optional.append(copy(p,'optional/'+root.parent.parent.name+'/'+f))
for root in [base/'com.lexi.v4.local/state/data/review_core_runtime',base/'com.lexi.review-core.local/state/data']:
 p=root/'review_bundle/20261009/current.json';optional.append(copy(p,'optional/'+root.parent.parent.name+'_'+root.name+'_current.json'))
save('optional_input_inventory.json',optional)
versions={'python':sys.version,'executable':sys.executable}
for x in ['pandas','pyarrow','pytest']:
 try:versions[x]=importlib.metadata.version(x)
 except:versions[x]=None
save('versions.json',versions);save('source_copy_index.json',refs)
print(json.dumps(info,ensure_ascii=False,indent=2));print('versions',versions)
