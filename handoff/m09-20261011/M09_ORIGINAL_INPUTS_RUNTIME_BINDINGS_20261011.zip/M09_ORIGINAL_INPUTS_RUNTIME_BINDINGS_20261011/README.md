# M09 原始输入与实际绑定（2026-10-11只读采集）

目标交易日 20261009；未启动producer、采集、测试、调度或部署，未修改V4或原始数据。

`originals/panel_20261009_required8.parquet` 是原1.38GB panel的同日8列完整投影，5126行无去重无填值，保留原Arrow类型。配套membership列出完整源T成员；不代表完整市场覆盖。原文件SHA及指针原字节在panel_evidence及originals。实现时创建本机候选指针指向解压后Parquet；原绝对指针作为证据不能直接跨机使用。相对指针按进程cwd解析。

关键缺口：源回执REBUILD_REQUIRED；2缺失bar_close_pos，137空名称，240空行业。不得伪造填值或升级为已验合法生产输入。最终panel available_at缺失，mtime不作时点证据。源80MB回执完整保留，ZIP压缩传输。

现役8873 GET已保存，A状态PARTIAL_STAGE_EVIDENCE；API根V4与producer根V3.5不同。只读绑定源代码、版本/lock、日历、1605/1710调度合同已收集；未运行旧测试。V5 M09发布配置未发现。候选须独立data_root，保留旧值，不直接replace共享V4存量。

视频和stage可选输入未齐不阻断基础实现；新review/回执/API结果属于输出，不要求父任务补造。详细分类见GAPS.json。GitHub移交由父任务执行。
